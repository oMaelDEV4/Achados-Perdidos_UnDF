﻿namespace PerdiNoCampus.API.Models
{
    public enum ECategoriaItem
    {
        AparelhoEletronico,
        Roupas,
        Documento,
        Outros
    }
}
