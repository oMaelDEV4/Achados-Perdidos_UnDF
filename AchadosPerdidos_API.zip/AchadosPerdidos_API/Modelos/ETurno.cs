﻿namespace PerdiNoCampus.API.Models
{
    public enum ETurno
    {
        Manha,
        Tarde,
        Noite
    }
}
